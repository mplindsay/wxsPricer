#!/bin/bash

PricerDir=$(dirname "$(readlink -f "$0")")/..
source $PricerDir/settings.sh

#
#	where are the xml and object file
#

GridRoot=$PricerDir/Grid
JavaDir=$PricerDir/java


#
#	where are the definiting xml for this grid?
#

GridXML="-objectgridFile $GridRoot/PricerGrid.xml"
DeployXML="-deploymentPolicyFile $GridRoot/PricerDeployment.xml"
ServerProps="-serverProps $GridRoot/server.properties"
Configuration="$GridXML $DeployXML $ServerProps"

echo
echo
echo starting containers
echo

$WxsBin/startXsServer.sh PricerContainer00 $CatalogEndpoints $Configuration -jvmArgs -classpath $JavaDir/PricerObjects.jar

$WxsBin/startXsServer.sh PricerContainer01 $CatalogEndpoints $Configuration -jvmArgs -classpath $JavaDir/PricerObjects.jar

$WxsBin/startXsServer.sh PricerContainer02 $CatalogEndpoints $Configuration -jvmArgs -classpath $JavaDir/PricerObjects.jar

echo
echo
echo You"'"re Welcome
echo
echo

