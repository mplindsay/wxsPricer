#!/bin/bash

PricerDir=$(dirname "$(readlink -f "$0")")/..
source $PricerDir/settings.sh

Containers=-"sl PricerContainer00,PricerContainer01,PricerContainer02"

$WxsBin/xscmd.sh -c teardown $Containers $CEP -f

echo
echo	You"'"re Welcome
echo
echo

