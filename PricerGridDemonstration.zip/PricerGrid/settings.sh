
#
#	where are the wxs start and stop programs? add that directory to the
#	class path
#

JAVA_HOME=$(cygpath -p -u '\WebSphere\JavaScript\Eclipse\ibm_sdk80')
OBJECTGRID_HOME=$(cygpath -p -u '\WebSphere\eXtremeScale\ObjectGrid')

WxsBin=$OBJECTGRID_HOME/bin
WxsLib=$OBJECTGRID_HOME/lib

PrcLib=$(cygpath -p -u '\Users\IBM_ADMIN\Documents\Enablements\WXS\PartitionableWorks')

echo WxsBin: $WxsBin
echo WxsLib: $WxsLib
echo PrcLib: $PrcLib


#
#	set endpoints
#

HostName="localhost"
HostPort="2809"

ListenerHost="-listenerHost $HostName"
ListenerEndpoint="$ListenerHost -listenerPort $HostPort"
CEP="-cep $HostName:$HostPort"
CatalogEndpoints="-catalogServiceEndPoints $HostName:$HostPort"

echo $ListenerHost
echo $CEP
echo $CatalogEndpoints
