@echo off

PricerDir=$(dirname "$(readlink -f "$0")")/..
source $PricerDir/settings.sh

$WxsBin/stopXsServer.sh Pricer00 $CatalogEndpoints

echo
echo
echo	You"'"re Welcome
echo

