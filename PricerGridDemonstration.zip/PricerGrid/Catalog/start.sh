#!/bin/bash

PricerDir=$(dirname "$(readlink -f "$0")")/..
source $PricerDir/settings.sh

#
# 	where in the net is this server running from? build me a listener argument
#

CatalogServiceEndpoints="-catalogServiceEndPoints Pricer00:$HostName:6603:6604"

echo
echo starting catalog
echo

$WxsBin/startXsServer.sh Pricer00 -domain PricerDomain $ListenerEndpoint

echo
echo
echo You"'"re Welcome
echo
echo
