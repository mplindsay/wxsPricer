package com.ibm.sdwet.pricer.object;

import java.io.Serializable;

public class Coupon implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	public String						id;
	public String						customerId;
	public String						productId;
	public int							discount;
	
	public Coupon (
		String							theCouponId,
		String							theCustomerId,
		String							theProductId,
		int								theDiscount
		)
	{
		id = theCouponId;
		customerId = theCustomerId;
		productId = theProductId;
		discount = theDiscount;
	}
}
