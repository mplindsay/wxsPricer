package com.ibm.sdwet.pricer.object;

import java.io.Serializable;

/**
 * The class keeps the <code>materialId</code> and the <code>listPrice</code>
 * 
 * @author mplindsay
 * @version 1.0
 *
 */

public class Product
	implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	public String						id;
	public float						listPrice;
	
	@SuppressWarnings("unused")
	private Product ()
	{
		// don't let anyone do this
	}
	
	public Product (
		String							theProductId,
		float							theListPrice
		)
	{
		id = theProductId;
		listPrice = theListPrice;
	}
}
