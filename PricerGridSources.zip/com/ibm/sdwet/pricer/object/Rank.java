package com.ibm.sdwet.pricer.object;

import java.io.Serializable;

public enum Rank implements Serializable
{
	GOLD,
	SILVER,
	BRONZE
}
