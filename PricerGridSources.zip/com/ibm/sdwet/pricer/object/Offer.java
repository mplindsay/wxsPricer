package com.ibm.sdwet.pricer.object;

import java.io.Serializable;

public class Offer implements Serializable
{
	private static final long serialVersionUID = 1L;

	public String						id;
	public String						productId;
	public Rank							rank;
	public int							discount;

	public Offer (
		String							theOfferId,
		String							theProductId,
		Rank							theRank,
		int								theDiscount
		)
	{
		id = theOfferId;
		productId = theProductId;
		rank = theRank;
		discount = theDiscount;
	}
}
