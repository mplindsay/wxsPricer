package com.ibm.sdwet.pricer.client;

/**
 * This class contains the tokens of a legal statement, as parsed by the
 * <code>StatementIterator</code>
 * and to be executed by the <code>PricerClient</code> application
 * 
 * @author mplindsay
 * @version 1.0
 *
 *@see PricerClient
 *@see StatementIterator
 */
public class Statement
{
	public enum Type
	{
		load,
		price,
		list,
		sizes,
		clear,
		help,
		exit,
		error
	}
	
	public Statement (
		Type							theType
		)
	{
		type = theType;
	}
	
	public Statement (
		Type							theType,
		String							theCustomerId,
		String							theProductId,
		int								theQuantity
		)
	{
		type = theType;
		customerId = theCustomerId;
		productId = theProductId;
		quantity = theQuantity;
	}
	
	public Statement (
			Type							theType,
			String							theMap,
			String							theKey
			)
		{
			type = theType;
			map = theMap;
			key = theKey;
		}
	
	public Type							type;
	
	public String						customerId;
	public String						productId;
	public int							quantity;
	
	public String						map;
	public String						key;

}
