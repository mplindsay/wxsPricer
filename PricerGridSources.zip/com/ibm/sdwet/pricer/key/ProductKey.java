package com.ibm.sdwet.pricer.key;

import java.io.Serializable;

import com.ibm.sdwet.pricer.object.Product;

/**
 * The class allows us to specify a partition key of our choosing to the WXS runtime,
 * so that we can copy a <code>Product</code> object to multiple partitions. The
 * <code>Product</code> object will be indexed at the partition by the
 * <code>productId</code>.
 * <p>
 * The range of partitions will be computed by the <code>ProductKeys</code> class.
 * 
 * @see Product
 * @see ProductKeys
 */

public class ProductKey
	extends PricerKeyBase implements Serializable
{

	private static final long serialVersionUID = 1L;

	/**
	 * The constructor will build a key from
	 * the <code>Product.id</code>'s <code>hashCode()</code> value and
	 * <code>thePartition</code> value
	 * 
	 * @param theProduct provides the <code>String id</code> from which our <code>hashCode()</code>
	 * will be derived
	 * @param thePartition is the int value from which an <code>Integer</code> will be constructed
	 * to represent our partition value
	 */
	public ProductKey (
		Product			theProduct,
		int				thePartition
		)
	{
		super (
			theProduct.id.hashCode(),
			new Integer(thePartition)
			);
	}

}
