package com.ibm.sdwet.pricer.key;

import java.io.Serializable;

import com.ibm.sdwet.pricer.object.Offer;

/**
 * The class allows us to specify a <code>ProductKey</code> which identifies a partition
 * where this of <code>Offer</code> must be co-located
 */

public class OfferKey
	extends PricerKeyBase implements Serializable
{

	private static final long serialVersionUID = 1L;
	
	/**
	 * 
	 * @param theOffer will provide the keys <code>hashCode()</code> value
	 * @param theProductKey will provide this keys <code>ibmGetPartition()</code> value
	 */

	public OfferKey (
		Offer							theOffer,
		ProductKey						theProductKey
		)
	{
		super (
			theOffer.id.hashCode(),
			(Integer) theProductKey.ibmGetPartition()
			);
	}
}
