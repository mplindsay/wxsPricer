package com.ibm.sdwet.pricer.key;

import java.io.Serializable;

import com.ibm.sdwet.pricer.object.Coupon;

/**
 * The class allows us to specify a <code>CustomerKey</code> which identifies a partition
 * where this of <code>Coupon</code> must be co-located
 * as a <code>Customer</code>
 */

public class CouponKey
	extends PricerKeyBase implements Serializable
{


	private static final long serialVersionUID = 1L;

	/**
	 * 
	 * @param theCoupon will provide the keys <code>hashCode()</code> value
	 * @param theCustomerKey will provide this key's <code>ibmGetPartition()</code> value
	 */
	public CouponKey (
		Coupon							theCoupon,
		CustomerKey						theCustomerKey
		)
	{
		super (
			theCoupon.id.hashCode(),
			(Integer) theCustomerKey.ibmGetPartition());
	}

}
