package com.ibm.sdwet.wxs.client;

public class GridException
	extends Exception
{
	private static final long serialVersionUID = 1L;

	public GridException(
		String							theMessage,
		Throwable						theCause
		)
	{
		super(theMessage + " because " + theCause);
		System.err.println (theMessage + " because " + theCause);
		theCause.printStackTrace(System.err);
	}

	public GridException(String theMessage)
	{
		super(theMessage);
		System.err.println (theMessage);
	}

	
}
